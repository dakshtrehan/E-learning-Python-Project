l=['1','2','3']
import os
import pickle
class student:           #student module
 #on main screen!
       def __str__(self):
              print "\t",self.name,"\t\t",self.subject,"\t\t",self.class1
              return" "
       def  EnterDetail(self):
              self.name=raw_input("\t\tEnter the name \t\t:")
              self.subject=raw_input("\t\tEnter your subject \t:")
              self.class1=input("\t\tEnter your Class \t:")
              print                    
x=student()

def Details():
       x.EnterDetail()     
def Show():
       if x.class1==12 and x.subject in ["Chemistry","chemistry","CHEMISTRY"]:
              print "\t\tYou Are Succesfully Login With Details"
              print "-"*80
              print "\tNAME\t\tSUBJECT\t\tCLASS"
              print "-"*80
              print x
              return True
       else:
              pass

def Showchap():
       o=open("Showchap.txt","r")
       t=o.read()
       print t
       o.close()

def  ad():
       print
       print 30*"_","User Login",30*"_"
       id1="admin"
       password="elearning"
       choice="yes"
       while choice=="yes":
              print
              print
              i=raw_input("Enter id to login : ")
              p=raw_input("Enter password : ")
              print
              if i==id1 and p==password:
                     print"\t\t\t*******************************"
                     print"\t\t\t*","                                                       " ,"*"
                     print"\t\t\t*  Press 1 For Adding Chapter       *"
                     print"\t\t\t*","                                                       ","*"   
                     print"\t\t\t*  Press 2 For Editing Content       *"
                     print"\t\t\t*", "                                                       ","*"
                     print"\t\t\t* Press 3 For Adding new Ques    *"
                     print"\t\t\t******************************"

 


                     print
                     d=input("\tEnter Your Choice : ")
                     print
                     if d==1:
                            print"WHICH CHAPTER YOU WANT TO ADD?"
                            print
                            n=raw_input("Enter the chapter number")
                            print
                            if n in l:
                                   print"This chapter is already in menu"
                                   print
                                   print"Press 1 to study!"
                                   h=raw_input("Enter 1")
                                   if h=='1':
                                          v="ch"+n+".txt"
                                          y=open(v,"r")
                                          s=y.read()
                                          print s
                                          y.close()
                                          break
                                   else:
                                          print"INVALID KEYWORD!"
                                          break
                            else:
                                   l.append(n)
                                   
                                   print l
                            h=raw_input("Enter the chapter name")
                            print
                            o=open("Showchap.txt","a")
                            line="\n"+n+"."+""+h
                            o.write(line)
                            s="ch"+n+".txt"
                            f=open(s,"w")
                            o.close()
                            f.close()
                     elif d==2:
                            print
                            print "CHOSE CHAPTER TO EDIT!"
                            print"_________________________"
                            print
                            Showchap()
                            print
                            ch=raw_input("Enter the chapter number:")
                            v1="ch"+ch
                            os.system(v1+".txt")
                     elif d==3:
                            print "Choose The chapter you want add question "
                            print
                            print
                            Showchap()
                            print
                            print"\t\t\t***************************************"
                            print"\t\t\t*","                                                                        " ,"*"
                            print"\t\t\t*  Press 1 For EXISTING CHAPTER             *"
                            print"\t\t\t*","                                                                        ","*"   
                            print"\t\t\t*  Press 2 For NEW CHAPTER                       *"
                            print"\t\t\t*", "                                                                        ","*"
                            print"\t\t\t***************************************"

                            print
                            b=input("\tEnter your choice")
                            print
                            if b==1:
                                   p=raw_input(" Choose The Chapter")
                                   import pickle
                                   v="quiz"+p+".txt"
                                   f=open(v,"ab")
                                   n=input("Enter the number of question")
                                   c=2
                                   for  i in range(n):
                                          c=c+1
                                          x=enter()
                                          print "====================================="
                                          x.enter(c)
                                          print "======================================"
                                          pickle.dump(x,f)
                                   f.close()
                            elif b==2:
                                   m=raw_input(" Choose The Chapter")
                                   import pickle
                                   v="quiz"+m+".txt"
                                   f=open(v,"ab")
                                   n=input("Enter the number of question")
                                   a=-1
                                   for  i in range(n):
                                          a=a+1
                                          x=enter()
                                          x.enter(a)
                                          print
                                          pickle.dump(x,f)
                                   f.close()
                     else:
                            print"You enter wrong keyword!"
              else:
                     print "THE USERNAME OR PASSWORD IS INCORRECT!!"
                     print
              choice=raw_input("Do you want to continue? Enter yes or no.. ")
              print 40*"_"
       else:
              pass

       
class enter:
    def enter(self,i):
        self.ques=raw_input("Enter the question:\t")
        print 
        self.op1=raw_input("Enter 1st option :\t\t\t")
        self.op2=raw_input("Enter 2nd option :\t\t")
        self.op3=raw_input("Enter 3rd option :\t\t")
        self.op4=raw_input("Enter 4th option :\t\t")
        print
        self.ans=raw_input("Enter the correct option \t\t")
        
        self.qno=i+1
    def show(self):
        print "========================================================="
        print "Q",self.qno,".",self.ques
        
        print  "1.",self.op1
        print  "2.",self.op2
        print  "3.",self.op3
        print  "4.",self.op4
        print"========================================================"

def Cn():
       
    import pickle
    n=raw_input("Enter chapter no.")
    v="quiz"+n+".txt"
    f=open(v,"ab")
    x=enter()
    a=returnque()
    x.enter(a)
    print " "
    pickle.dump(x,f)
    f.close()
    
def returnque():
       import pickle
       f=open(v,"rb")
       while True:
              try :
                     obj=pickle.load(f)
                      
              except EOFError:
                     break
       f.close()
       return obj.qno
def SHOWQUES():
       sum1=0
       count=0
       n=raw_input("Enter The Chapter number ")
       v="quiz"+n+".txt"
       import pickle
       f=open(v,"rb")
       while True:
              try :
                     obj=pickle.load(f)
                     obj.show()
                     a=raw_input("Enter the answer")
                    
                     
                     if a==obj.ans:
                            print
                            print "Your Answer is Correct"
                            print
                            sum1=sum1+4
                            count=count+1
                     else:
                            print
                            print "Your Answer is Wrong"
                            print
                            print "Correct Answer is ",obj.ans
                            print
                            count=count+1
                            print
       
                        
                     
              except EOFError:
                     break
       print
       print "Your Total Score","Out Of ",count*4,"is",sum1       
       f.close()

def new():
    import pickle
    f=open(v,"ab")
    n=input("Enter the number of question")
    global i
    for  i in range(n):
        x=enter()
        x.enter(i)
       
        print
        pickle.dump(x,f)
    f.close()
