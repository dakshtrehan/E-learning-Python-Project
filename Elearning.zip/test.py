
class enter():
    def enter(self,i):
        self.ques=raw_input("Enter the question:")
        self.op1=raw_input("Enter 1st option")
        self.op2=raw_input("Enter 2nd option")
        self.op3=raw_input("Enter 3rd option")
        self.op4=raw_input("Enter 4th option")
        self.ans=raw_input("Enter the ans")        
        self.qno=i+1
    def show(self):
        print "Q",self.qno,".",self.ques
        print "a.",self.op1
        print "b.",self.op2
        print "c.",self.op3
        print "d.",self.op4
n=raw_input("Enter chapter no.")
v="quiz"+n+".txt"

def Cn():
    import pickle
    n=raw_input("Enter chapter no.")
    v="quiz"+n+".txt"
    f=open(v,"ab")
    x=enter()
    a=returnque()
    x.enter(a)
    print " "
    pickle.dump(x,f)
    f.close()
    
def returnque():
       import pickle
       f=open(v,"rb")
       while True:
              try :
                     obj=pickle.load(f)
                     
              except EOFError:
                     break
       f.close()
       return obj.qno
def SHOWQUES():
       import pickle
       f=open(v,"rb")
       while True:
              try :
                     obj=pickle.load(f)
                     obj.show()
                     a=raw_input("ENter the answer")
                     if a==obj.ans:
                         print "corrct"
                     else:
                        print "Wrong"
                     
              except EOFError:
                     break
       f.close()

def new():
    import pickle
    f=open(v,"ab")
    n=input("Enter the number of question")
    for  i in range(n):
        x=enter()
        x.enter(i)
        print
        pickle.dump(x,f)
    f.close()
