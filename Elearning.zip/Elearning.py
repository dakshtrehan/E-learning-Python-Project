l=["1","2","3"]
import pickle
choice="yes"
while choice.lower()=="yes":
    print"*****************************************************************************"*2
    print"*       xxxxxxxxxxx    xx           xxxxxxxxx                 xx xx           xxxxxxxxx  x                 xx  xx  xx                 xx  xxxxxxxx     *"
    print"*       xx             xx           xx                       xx    xx         xx     xx  xxxx            xx   xx  xxxx            xx  xx                   *"                
    print"*       xx             xx           xx                      xx       xx       xx    xx   xx     xx       xx   xx  xx     xx       xx  xx                   *"
    print"*       xxxxxx     === xx           xxxxxx                 xxxxxxxxxxxxx      xx  xx     xx    xx   xx  xx        xx    xx  xx                    *"
    print"*       xx             xx           xx                    xx            xx    xx xx      xx          xx  xx   xx  xx          xx  xx  xx     xxxx     *"
    print"*       xx             xx           xx                   xx              xx   xx  xx     xx            xxxx   xx  xx            xxxx  xx         xx      *"
    print"*       xxxxxxxxxxx    xxxxxxxxx    xxxxxxxxx           xx                xx  xx   xx    xxx   xx  xx              xxx  xxxxxxxx       *"
    print"******************************************************************************"*2
    print  
    import classes
    import pickle
    classes.Details()
    while classes.Show()==True:
        print
        print
        ch="yes"
        while ch.lower()=="yes":
            print"\t\t\t@@@@@@@@@@@@@@@@@@@@@"
            print"\t\t\t@______________CLASS 12  CHEMISTRY______________@"
            print"\t\t\t@","                                                                                                        ","@"
            print"\t\t\t@______________ENTER 1 TO STUDY_________________@"
            print"\t\t\t@______________ENTER 2 FOR QUIZ_________________ @"
            print"\t\t\t@______________ENTER 3 FOR ADMIN LOGIN__________@"
            print"\t\t\t@","                                                                                                          ","@"
            print"\t\t\t@@@@@@@@@@@@@@@@@@@@@@@"
            print
            chose=input("\t\t\tEnter your choice:")
            if chose==1:
                print
                print"\t\tCHOSE CHAPTER TO STUDY"
                print"\t\t==============================="
                print
                classes.Showchap()
                print
                ch=raw_input("Enter the Chapter Number you want to study:")
                print

                print
                try:
                    v='ch'+ch+".txt"
                    o=open(v,"r")
                    s=o.read()
                    print s
                    o.close()
                except:
                    print"THE CONTENT OF CHAPTER IS NOT AVAILABLE YET"
                    print "============================================"
            elif chose==2:
                class enter():
                    def enter(self,i):
                        self.ques=raw_input("Enter the question:")
                        print
                        self.op1=raw_input("Enter 1st option\t\t")
                        self.op2=raw_input("Enter 2nd option\t\t")
                        self.op3=raw_input("Enter 3rd option\t\t")
                        self.op4=raw_input("Enter 4th option\t\t")
                        print
                        self.ans=raw_input("Enter the ans\t\t")
                        print "\t\t================================================"
                        self.qno=i+1
                    def show(self):
                        print "=================================================="
                        print "Q",self.qno,".",self.ques
                        print
                        print   "\t1.",self.op1
                        print   "\t2.",self.op2
                        print   "\t3.",self.op3
                        print   "\t4.",self.op4
                        print "===================================================="
                print
                print"\t\tCHOSE CHAPTER TO QUIZ"
                print"\t\t==============================="
                print
                classes.Showchap()
                print
                print
        
                print
                classes.SHOWQUES()
                print "*******************************************"
                
                

                
    
               
            elif chose==3:
                classes.ad()
            else:
                print"You entered the invalid choice!"
            print"*****************************************"
            print
            print"Press Yes to go to Main Menu!"
            ch=raw_input()
            print
            print"*****************************************"
        else:
            print"Enter Yes to login again"
            choice=raw_input()
    else:
        print"CONTENT NOT AVAILABE YET!"
        break
else:
    print"\t\t\t\t PROGRAM OVER"
    print"========================================================="
    print
     
        
        

